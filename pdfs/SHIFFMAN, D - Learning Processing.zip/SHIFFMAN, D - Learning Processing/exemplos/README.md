Learning Processing
==================

This repository includes all of the examples for the book [Learning Processing](http://www.amazon.com/gp/product/0123736021/ref=as_li_ss_tl?ie=UTF8&camp=1789&creative=390957&creativeASIN=0123736021&linkCode=as2&tag=shiffman-20), a beginners guide to programming images, animation and interaction.

The book was written in 2008 and all of the examples were built for Processing 1.0.  I am in the process of updating everything for Processing 2.0 and welcome any issues and pull requests.

[![](http://shiffman.net/books/lp_cover.png)](http://www.amazon.com/gp/product/0123736021/ref=as_li_ss_tl?ie=UTF8&camp=1789&creative=390957&creativeASIN=0123736021&linkCode=as2&tag=shiffman-20)

- Visit the [_Learning Processing_ website](http://learningprocessing.com)
- [Buy _Learning Processing_ on Amazon.com](http://www.amazon.com/gp/product/0123736021/ref=as_li_ss_tl?ie=UTF8&camp=1789&creative=390957&creativeASIN=0123736021&linkCode=as2&tag=shiffman-20)
